library(ggplot2)
library(reshape2)
library(dplyr)
library(viridis)
library(lubridate)
library(foreach)

setwd("P:/eDNA/eDNA BilagaScript/Fish_Barplot")

#Load data for each inentory
Aug20=read.csv("101816_FishP.csv", fileEncoding = "UTF-8-BOM")
Jun21=read.csv("102635_FishP.csv", fileEncoding = "UTF-8-BOM")
Sep21=read.csv("102822_FishP.csv", fileEncoding = "UTF-8-BOM")

#Notices that the column name for the species in these datasets is "X"
Aug20$X=gsub("Spratus spratus", "Sprattus sprattus", Aug20$X) 

#Prep Aug 
Aug20$Month = rep("Aug", length(Aug20$X1B))
mltAug=melt(Aug20,id.vars = c("Month", "X"))
#Prep June
Jun21$Month = rep("Jun", length(Jun21$X))
mltJun=melt(Jun21,id.vars = c("Month", "X"))
#Prep Sep 
Sep21$Month = rep("Sep", length(Sep21$X))
mltSep=melt(Sep21,id.vars = c("Month", "X"))

#Summary of fish abundance in respective dataset for overview
sort(tapply(mltJun$value, mltJun$X, sum), decreasing = TRUE)
sort(tapply(mltAug$value, mltAug$X, sum), decreasing = TRUE)
sort(tapply(mltSep$value, mltSep$X, sum), decreasing = TRUE)

#Merge the inventories into one dataset
mltBig=rbind(mltJun, mltAug, mltSep)
theSum=sum(sort(tapply(mltBig$value, mltBig$X, sum), decreasing = TRUE))
sort(tapply(mltBig$value, mltBig$X, function(x) (sum(x)/theSum)*100), decreasing = TRUE)

#Line too remove species that are deemed to be contamination or freshwater
mltBig = mltBig[which(mltBig$X !=  "Scomber scombrus" & mltBig$X != "Perca fluviatilis" & mltBig$X != "Esox lucius"), ]

#Export a file that can be used for species translation, upload and download through "namnochsl�ktskap" webpage. 
write.csv(unique(mltBig$X), "Latin_ArtLista_Aurora.csv", row.names = FALSE, fileEncoding = "UTF-8")
trnsDf=read.csv("Swe_ArtLista_Aurora.csv", header=TRUE,skip=1, fileEncoding = "UTF-8-BOM")

foreach(lat = trnsDf$LatNamn, swe = trnsDf$SweNamn) %do%{
  mltBig$X=gsub(lat,swe, mltBig$X)
}

#Overview of Species abundance by inventory
spAbn=melt(tapply(mltBig$value, list(mltBig$X,mltBig$Month), mean))
spAbn[order(spAbn$Var2, spAbn$value, decreasing = TRUE),]
spAbn$Fact = as.factor(rep(1, length(spAbn$Var1)))

laxDf = spAbn[which(spAbn$Var1 == "lax"),]
intList = c("2021-08-01", "2021-06-01", "2021-09-01")
monList=as.vector(unique(spAbn$Var2))

#Translates dates to month names, e.g. Jun-Jul-Aug
foreach(aMon=monList, aInt = intList)%do%{
  spAbn$Var2 = gsub(aMon, aInt, spAbn$Var2)
}

spAbn$Var2 = month(spAbn$Var2, label=TRUE)

#Change data type, sorting and change NA to 0. 
mltBig$X = as.factor(mltBig$X)
mltBig$Month = as.factor(mltBig$Month)
mltBig=mltBig[order(mltBig$value, decreasing = TRUE),]
spAbn$value[is.na(spAbn$value)] = 0 

#Removes unwanted species
spAbn = spAbn[which(spAbn$Var1 != "Tachysurus ful."),]
spAbn = spAbn[which(spAbn$Var1 != "Platichthys stl."),]
spAbn = spAbn[which(spAbn$Var1 != "fj�rsing"),]
spAbn = spAbn[which(spAbn$Var1 != "l�ja"),]
spAbn = spAbn[which(spAbn$Var1 != "braxen"),]
spAbn = spAbn[which(spAbn$Var1 != "st�m"),]
spAbn = spAbn[which(spAbn$Var1 != "knot"),]
spAbn = spAbn[which(spAbn$Var1 != "karpfiskar"),]
spAbn = spAbn[which(spAbn$Var1 != "gr�sej"),]
spAbn = spAbn[which(spAbn$Var1 != "stensnultra"),]

spAbn$Var1 = gsub("^simpa$", "r�tsimpa/hornsimpa", spAbn$Var1)
spAbn$Var1 = gsub("l�j", "l�ja", spAbn$Var1)
spAbn$Var1 = gsub("Sk�rl�nga", "sk�rl�nga", spAbn$Var1)
spAbn$Var1 = gsub("^sill$", "str�mming", spAbn$Var1)

hstG2 = ggplot(spAbn)
hstG2 = hstG2 + geom_bar(stat="identity", position = "dodge", aes(x=reorder(Var1, value, sum), y=value, fill = Var2))+ facet_grid(~Var2)+theme_bw()
hstG2 = hstG2 + theme(axis.text.x = element_text(size = 15, vjust = 0.2), 
                      axis.text.y = element_text(size = 15),legend.position = "none", 
                      axis.title.x = element_text(size=18), axis.ticks = element_blank())
hstG2 = hstG2 + labs(x="", y="Procentuell andel av fisksamh�llet", subtitle="Genomsnittlig signalstyrka per m�nad, Aurora fisk 2020-2021")+
  scale_fill_manual(values = c("#C4DFCC", "#0086ad", "#005582"))
hstG2 = hstG2 + theme(plot.subtitle=element_text(size=24, hjust=0, color="black"), strip.text.x = element_text(size=20))
hstG2 = hstG2 + coord_flip()














###NMDS Of Aurorar 2020-2021### 
library(vegan)
library(stringr)

#Prepare and merge data for NMDS
Aug20=read.csv("101816_FishP.csv", fileEncoding = "UTF-8-BOM", row.names = 1)
#Mar21=read.csv("101893_FishP.csv", fileEncoding = "UTF-8-BOM", row.names = 1)
Jun21=read.csv("102635_FishP.csv", fileEncoding = "UTF-8-BOM", row.names = 1)
Sep21=read.csv("102822_FishP.csv", fileEncoding = "UTF-8-BOM", row.names = 1)

rm(list=ls())

#Mar21[27,] = rep(0, dim(Mar21)[2])
#row.names(Mar21)[27] = "Belone belone"
Aug20[16,] = rep(0, dim(Aug20)[2])
row.names(Aug20)[16] = "Platichthys flesus"

colnames(Aug20)=gsub("X", "Aug", colnames(Aug20))
#colnames(Mar21)=gsub("A", "Mar", colnames(Mar21))
colnames(Jun21)=gsub("A", "Jun", colnames(Jun21))
colnames(Sep21)=gsub("A", "Sep", colnames(Sep21))

spcVec=c("Clupea harengus", "Gadus morhua","Sprattus sprattus","Myoxocephalus","Belone belone","Gasterosteus aculeatus","Platichthys flesus")
spcVec=paste(spcVec, collapse = "|")

Aug20=Aug20[grepl(spcVec, row.names(Aug20)),]
#Mar21=Mar21[grepl(spcVec, row.names(Mar21)),]
Jun21=Jun21[grepl(spcVec, row.names(Jun21)),]
Sep21=Sep21[grepl(spcVec, row.names(Sep21)),]

mrgDf=as.data.frame(t(cbind(Aug20, Jun21, Sep21)))
mrgDf$tempSum=rowSums(mrgDf)
mrgDf=mrgDf[which(mrgDf$tempSum > 10),]
mrgDf = mrgDf[,-dim(mrgDf)[2]]

#NMDS 
mrgNMDS=metaMDS(mrgDf, distance = "bray", maxtry = 200)
mrgScore = as.data.frame(scores(mrgNMDS))

#Prepare variables for plot
mrgScore$Name=row.names(mrgScore)
mrgScore$Month=unlist(str_extract_all(mrgScore$Name, "^([A-Za-z]){3}"))
mrgScore$Depth = unlist(str_extract_all(mrgScore$Name, "(Y|B){1}$"))

mrgScore$Depth=gsub("B", "Botten", mrgScore$Depth)
mrgScore$Depth=gsub("Y", "Yta", mrgScore$Depth)

#"2021-03-01", 
intList = c("2021-08-01","2021-06-01", "2021-09-01")
monList=as.vector(unique(mrgScore$Month))

foreach(aMon=monList, aInt = intList)%do%{
  mrgScore$Month = gsub(aMon, aInt, mrgScore$Month)
}
mrgScore$Month = month(mrgScore$Month, label=TRUE)

levels(mrgScore$Depth) = c("Botten", "Yta")

gaMDS=ggplot(mrgScore, aes(x=NMDS1, y=NMDS2, color = Month, shape=Depth))
gaMDS = gaMDS + geom_point(size=5)
gaMDS = gaMDS + theme_bw()
gaMDS = gaMDS + scale_color_manual(values=c("#C4DFCC", "#00c2c7", "#0086ad", "#005582")) 
gaMDS = gaMDS + theme(legend.title = element_blank(), legend.position = "right")+labs(subtitle = "NMDS: Aurora inventeringar eDNA-fisk 2020-2021") 
gaMDS = gaMDS + theme(plot.subtitle = element_text(size=26, hjust=0), axis.text = element_text(size = 22),axis.title = element_text(size = 22), legend.text = element_text(size=22))

sumFish=sum(spAbn$value)
options(scipen = 999)

fishStat=sort(tapply(spAbn$value, spAbn$Var1, sum)/sumFish, decreasing = TRUE)

spAbn$value[spAbn$value>0] = 1

sort(tapply(spAbn$value, spAbn$Var1,sum), decreasing = TRUE)

sum(fishStat[1:5])
sum(fishStat[6:34])

