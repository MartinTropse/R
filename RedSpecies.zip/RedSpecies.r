library(reshape2)
library(data.table)
library(readr)



setwd("C:/Bas/AquaBiota/Projekt/OX2/Bentos punktkartor/R�dlistade arter")

list.files()
df=read.csv("Redlist_GG_Proxim.csv", sep=',', encoding = 'UTF-8')



length(unique(df$Latitud))
length(unique(df$Longitud))

df$Coord<- with(df, paste(Latitud, Longitud))

out=tapply(df$Redlistade.arter, df$Coord, table)
a=do.call(rbind,out)

write.csv(a, "RedlistSpec_UniqueLocation.csv", fileEncoding = "UTF-8")


df=read.csv("Redlist_Parse.csv", sep=',', encoding = 'UTF-8')
sub=df[which(df$Uppdelning == "Kr�ftdjur"),]

#sub=df[which(df$Undergrupp == "Kr�ftdjur"),]


sub=sub[,1:140]

write.csv(sub, "RedlistPie_Kraft.csv", row.names = FALSE)
